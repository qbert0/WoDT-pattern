import time

from device.config import DEVICE, MQTT
from device.mqtt_client import KettleMqttClient
from device.simulator import KettleSimulator


def main() -> None:
    simulator = KettleSimulator()
    mqtt_client = KettleMqttClient(on_command=simulator.apply_command)

    print("=" * 60)
    print("Smart Kettle Device Simulator")
    print("=" * 60)
    print(f"Broker: {MQTT.host}:{MQTT.port}")
    print(f"Publish state topic: {MQTT.state_topic}")
    print(f"Subscribe command topic: {MQTT.command_topic}")
    print("=" * 60)

    mqtt_client.connect()
    mqtt_client.loop_start()

    try:
        while True:
            state = simulator.tick()
            mqtt_client.publish_state(state)
            print(f"[STATE] {state}")
            time.sleep(DEVICE.tick_seconds)
    except KeyboardInterrupt:
        print("\nStopping device simulator...")
    finally:
        mqtt_client.loop_stop()
        mqtt_client.disconnect()


if __name__ == "__main__":
    main()
