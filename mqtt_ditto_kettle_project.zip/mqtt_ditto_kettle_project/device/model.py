from dataclasses import dataclass, asdict

@dataclass
class KettleState:
    power: str = "off"
    targetTemperature: float = 90.0
    temperature: float = 25.0
    heating: bool = False
    connected: bool = True

    def to_payload(self) -> dict:
        return asdict(self)
