from device.config import DEVICE
from device.model import KettleState


class KettleSimulator:
    def __init__(self) -> None:
        self.state = KettleState(temperature=DEVICE.ambient_temperature)

    def apply_command(self, command: dict) -> None:
        power = command.get("power")
        target = command.get("targetTemperature")

        if power in {"on", "off"}:
            self.state.power = power
            self.state.heating = power == "on"

        if isinstance(target, (int, float)):
            self.state.targetTemperature = float(target)

    def tick(self) -> dict:
        if self.state.power == "on":
            if self.state.temperature < self.state.targetTemperature:
                self.state.temperature = min(
                    self.state.targetTemperature,
                    self.state.temperature + DEVICE.heat_step,
                )
                self.state.heating = self.state.temperature < self.state.targetTemperature
            else:
                self.state.heating = False
        else:
            if self.state.temperature > DEVICE.ambient_temperature:
                self.state.temperature = max(
                    DEVICE.ambient_temperature,
                    self.state.temperature - DEVICE.cool_step,
                )
            self.state.heating = False

        return self.state.to_payload()
