import json
from typing import Callable

import paho.mqtt.client as mqtt

from device.config import MQTT


class KettleMqttClient:
    def __init__(self, on_command: Callable[[dict], None]) -> None:
        self.on_command = on_command
        self.client = mqtt.Client(client_id=MQTT.client_id, protocol=mqtt.MQTTv311)
        self.client.on_connect = self._on_connect
        self.client.on_message = self._on_message

    def connect(self) -> None:
        self.client.connect(MQTT.host, MQTT.port, keepalive=60)

    def loop_start(self) -> None:
        self.client.loop_start()

    def loop_stop(self) -> None:
        self.client.loop_stop()

    def disconnect(self) -> None:
        self.client.disconnect()

    def publish_state(self, state_payload: dict) -> None:
        payload = json.dumps(state_payload, ensure_ascii=False)
        self.client.publish(MQTT.state_topic, payload, qos=0, retain=False)

    def _on_connect(self, client, userdata, flags, reason_code, properties=None):
        print(f"[MQTT] Connected with code={reason_code}")
        client.subscribe(MQTT.command_topic)

    def _on_message(self, client, userdata, msg):
        try:
            payload = json.loads(msg.payload.decode("utf-8"))
            print(f"[MQTT] Command received on {msg.topic}: {payload}")
            self.on_command(payload)
        except Exception as exc:
            print(f"[MQTT] Invalid command payload: {exc}")
