from dataclasses import dataclass

@dataclass(frozen=True)
class MqttConfig:
    host: str = "localhost"
    port: int = 1883
    state_topic: str = "devices/demo:kettle-01/state"
    command_topic: str = "devices/demo:kettle-01/commands"
    client_id: str = "kettle-device-01"

@dataclass(frozen=True)
class DeviceConfig:
    thing_id: str = "demo:kettle-01"
    tick_seconds: float = 2.0
    ambient_temperature: float = 25.0
    heat_step: float = 6.0
    cool_step: float = 2.5

MQTT = MqttConfig()
DEVICE = DeviceConfig()
