# MQTT + Device + Ditto demo

## Cấu trúc
- `device/`: code thiết bị giả lập
- `ditto/`: file cấu hình connection cho Ditto
- `scripts/`: script tạo thing, tạo connection, gửi command

## Chạy nhanh

### 1. Chạy Mosquitto
```bash
docker rm -f mosquitto
docker run -d --name mosquitto -p 1883:1883 eclipse-mosquitto
```

### 2. Tạo thing
```bash
chmod +x scripts/create_thing.sh
./scripts/create_thing.sh
```

### 3. Tạo connection
Nếu Ditto chạy trong Docker và Mosquitto chạy trên host, giữ nguyên:
`tcp://host.docker.internal:1883`

Nếu Ditto và Mosquitto cùng network Docker, sửa trong `ditto/mqtt-connection.json` thành:
`tcp://mosquitto:1883`

Sau đó:
```bash
chmod +x scripts/create_connection.sh
./scripts/create_connection.sh
```

### 4. Chạy thiết bị
```bash
pip install -r requirements.txt
python -m device.main
```

### 5. Gửi lệnh
```bash
chmod +x scripts/send_command.sh
./scripts/send_command.sh on 95
```

## Pub/Sub
- Device publish: `devices/demo:kettle-01/state`
- Device subscribe: `devices/demo:kettle-01/commands`
- Ditto subscribe source state topic và publish command topic
