#!/usr/bin/env bash
set -e

POWER="${1:-on}"
TARGET="${2:-95}"
DITTO_BASE="${DITTO_BASE:-http://localhost:8080}"
AUTH="${DITTO_AUTH:-ditto:ditto}"

curl -u "$AUTH" -X PATCH "$DITTO_BASE/api/2/things/demo:kettle-01" \
  -H "Content-Type: application/json" \
  -d "{
    \"features\": {
      \"control\": {
        \"properties\": {
          \"power\": \"$POWER\",
          \"targetTemperature\": $TARGET
        }
      }
    }
  }"
echo
