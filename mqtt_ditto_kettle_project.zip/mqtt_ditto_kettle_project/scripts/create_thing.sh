#!/usr/bin/env bash
set -e

DITTO_BASE="${DITTO_BASE:-http://localhost:8080}"
AUTH="${DITTO_AUTH:-ditto:ditto}"

curl -u "$AUTH" -X PUT "$DITTO_BASE/api/2/things/demo:kettle-01" \
  -H "Content-Type: application/json" \
  -d '{
    "thingId": "demo:kettle-01",
    "features": {
      "status": {
        "properties": {
          "power": "off",
          "targetTemperature": 90,
          "temperature": 25,
          "heating": false,
          "connected": true
        }
      },
      "control": {
        "properties": {
          "power": "off",
          "targetTemperature": 90
        }
      }
    }
  }'
echo
