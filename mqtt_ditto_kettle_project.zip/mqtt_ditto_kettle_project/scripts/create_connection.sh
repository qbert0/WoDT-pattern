#!/usr/bin/env bash
set -e

DITTO_BASE="${DITTO_BASE:-http://localhost:8080}"
AUTH="${DITTO_AUTH:-ditto:ditto}"

curl -u "$AUTH" -X PUT "$DITTO_BASE/api/2/connections/mqtt-kettle-connection" \
  -H "Content-Type: application/json" \
  --data-binary @ditto/mqtt-connection.json
echo
